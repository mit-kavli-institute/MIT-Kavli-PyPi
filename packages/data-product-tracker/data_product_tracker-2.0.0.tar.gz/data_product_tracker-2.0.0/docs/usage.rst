=====
Usage
=====

To use Data Product Tracker in a project::

    import data_product_tracker
