"""Version information for configurables."""

__version__ = "1.1.0"