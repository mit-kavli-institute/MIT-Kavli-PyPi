import uuid
from typing import TYPE_CHECKING

import numpy as np
import sqlalchemy as sa
from numpy import typing as npt
from sqlalchemy import orm

from lightcurvedb.core.base_model import LCDBModel

if TYPE_CHECKING:
    from lightcurvedb.models.dataset import DataSet
    from lightcurvedb.models.frame import FITSFrame
    from lightcurvedb.models.instrument import Instrument
    from lightcurvedb.models.quality_flag import QualityFlagArray
    from lightcurvedb.models.target import Target


class Observation(LCDBModel):
    """
    Base class for astronomical observations.

    Observation is a polymorphic base class that represents a collection
    of measurements taken by an instrument. Subclasses can specialize
    this for different observation types while maintaining a common interface.

    This design allows mission-specific observations (e.g., TESSObservation,
    HSTObservation) to extend the base model with mission-specific fields
    while sharing common functionality.

    Attributes
    ----------
    id : int
        Primary key identifier
    type : str
        Polymorphic discriminator for subclass type
    cadence_reference : ndarray[int64]
        Array of cadence numbers for time ordering
    instrument_id : uuid.UUID
        Foreign key to the instrument used
    instrument : Instrument
        The instrument that made this observation
    datasets : list[DataSet]
        Processed versions of this observation
    target_specific_times : list[TargetSpecificTime]
        Target-specific time corrections

    Examples
    --------
    Creating a mission-specific observation subclass:

    >>> class TESSObservation(Observation):
    ...     __mapper_args__ = {
    ...         "polymorphic_identity": "tess_observation",
    ...     }
    ...     sector: Mapped[int]
    ...     orbit_number: Mapped[int]

    Notes
    -----
    This is a polymorphic base class using single table inheritance.
    The 'type' field determines the specific observation subclass.
    Mission-specific fields should be added via subclassing, not by
    modifying this base class.
    """

    __tablename__ = "observation"
    __mapper_args__ = {
        "polymorphic_identity": "observation",
        "polymorphic_on": "type",
    }
    __table_args__ = (
        sa.Index(
            "ix_observation_cadence_length",
            sa.func.cardinality(sa.column("cadence_reference")),
        ),
        sa.Index(
            "ix_observation_cadence_min",
            sa.column("cadence_reference", type_=sa.ARRAY(sa.BIGINT))[1],
        ),
        sa.Index(
            "ix_observation_cadence_max",
            sa.column("cadence_reference", type_=sa.ARRAY(sa.BIGINT))[
                sa.func.cardinality(sa.column("cadence_reference"))
            ],
        ),
    )

    id: orm.Mapped[int] = orm.mapped_column(primary_key=True)
    type: orm.Mapped[str] = orm.mapped_column(index=True)
    cadence_reference: orm.Mapped[npt.NDArray[np.int64]]
    instrument_id: orm.Mapped[uuid.UUID] = orm.mapped_column(
        sa.ForeignKey("instrument.id", ondelete="CASCADE")
    )

    instrument: orm.Mapped["Instrument"] = orm.relationship(
        "Instrument", back_populates="observations"
    )

    datasets: orm.Mapped[list["DataSet"]] = orm.relationship(
        "DataSet", back_populates="observation"
    )
    target_specific_times: orm.Mapped[
        list["TargetSpecificTime"]
    ] = orm.relationship(
        back_populates="observation",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    quality_flag_arrays: orm.Mapped[
        list["QualityFlagArray"]
    ] = orm.relationship(
        "QualityFlagArray",
        back_populates="observation",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    fits_images: orm.Mapped[list["FITSFrame"]] = orm.relationship(
        "FITSFrame", back_populates="observation"
    )

    def align_to_reference(
        self,
        observed: npt.NDArray[np.integer],
        values: npt.NDArray,
        fill_value=np.nan,
        verify_subset: bool = False,
    ) -> npt.NDArray:
        """
        Align observed values to a reference sample grid.

        Parameters
        ----------
        observed : ndarray of int
            Monotonically increasing sample indices where values were observed.
            Must be a proper subset of the observation's cadence reference.
        values : ndarray
            Values corresponding 1-to-1 with observed.
        fill_value : scalar, optional
            Value for missing samples (default: np.nan).
        verify_subset : bool, optional
            If True, verify observed ⊂ reference (default: False).

        Returns
        -------
        aligned : ndarray
            Values aligned to reference grid, shape (len(reference),).
        """
        reference = self.cadence_reference
        indices = np.searchsorted(reference, observed)

        # Check which indices are within bounds
        in_bounds = indices < len(reference)

        if verify_subset:
            # All indices must be in bounds and match reference values
            valid = in_bounds.copy()
            valid[in_bounds] &= (
                reference[indices[in_bounds]] == observed[in_bounds]
            )
            if not valid.all():
                raise ValueError("observed contains values not in reference")

        result = np.full(
            len(reference),
            fill_value,
            dtype=np.result_type(values, fill_value),
        )
        # Only assign values for in-bounds indices
        result[indices[in_bounds]] = values[in_bounds]

        return result

    def __repr__(self) -> str:
        return (
            f"<{self.__class__.__name__}(id={self.id!r}, type={self.type!r}, "
            f"instrument={self.instrument_id!s})>"
        )

    def __rich_repr__(self):
        yield "id", self.id
        yield "type", self.type
        yield "instrument", self.instrument_id


class TargetSpecificTime(LCDBModel):
    """
    Time series data specific to a target-observation pair.

    This model stores barycentric-corrected time values that account
    for the specific position of a target. It serves as a junction
    between Target and Observation with additional time data.

    Uses a composite primary key (observation_id, target_id) and is
    partitioned by observation_id using PostgreSQL LIST partitioning.

    Attributes
    ----------
    observation_id : int
        Foreign key to the observation (part of composite PK, partition key)
    target_id : int
        Foreign key to the target (part of composite PK)
    barycentric_julian_dates : ndarray[float64]
        Array of barycentric Julian dates corrected for target position
    target : Target
        The astronomical target
    observation : Observation
        The observation these times correspond to

    Notes
    -----
    Barycentric correction accounts for Earth's motion around the
    solar system barycenter, providing consistent timing for
    astronomical observations.
    """

    __tablename__ = "target_specific_time"

    __table_args__ = (
        sa.PrimaryKeyConstraint(
            "observation_id", "target_id", name="pk_target_specific_time"
        ),
        {"postgresql_partition_by": "LIST (observation_id)"},
    )

    observation_id: orm.Mapped[int] = orm.mapped_column(
        sa.ForeignKey("observation.id", ondelete="CASCADE"),
        nullable=False,
    )
    target_id: orm.Mapped[int] = orm.mapped_column(
        sa.ForeignKey("target.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    barycentric_julian_dates: orm.Mapped[npt.NDArray[np.float64]]

    # Relationships
    target: orm.Mapped["Target"] = orm.relationship(
        back_populates="target_specific_times"
    )
    observation: orm.Mapped["Observation"] = orm.relationship(
        back_populates="target_specific_times"
    )

    def __repr__(self) -> str:
        return (
            f"<TargetSpecificTime(obs={self.observation_id!r}, "
            f"target={self.target_id!r})>"
        )

    def __rich_repr__(self):
        yield "observation_id", self.observation_id
        yield "target_id", self.target_id
