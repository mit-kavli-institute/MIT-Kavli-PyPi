def test_import():
    from lightcurvedb import db, db_from_config  # noqa
