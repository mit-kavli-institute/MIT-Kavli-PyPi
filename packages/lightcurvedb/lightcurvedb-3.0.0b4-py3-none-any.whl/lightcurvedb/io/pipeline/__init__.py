from lightcurvedb.io.pipeline.scope import db_scope

__all__ = ["db_scope"]
