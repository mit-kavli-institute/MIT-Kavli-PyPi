=====
Usage
=====

To use PyTICDB in a project::

    import pyticdb
