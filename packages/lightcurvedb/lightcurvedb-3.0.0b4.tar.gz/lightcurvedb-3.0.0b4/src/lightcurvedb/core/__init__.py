# Core submodule - imports directly from submodules as needed
