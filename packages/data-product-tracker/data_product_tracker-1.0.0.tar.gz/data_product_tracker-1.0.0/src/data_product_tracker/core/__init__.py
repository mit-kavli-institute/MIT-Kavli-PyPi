"""Core functionality package."""
