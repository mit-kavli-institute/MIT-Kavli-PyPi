import warnings

warnings.warn(
    "Entering experimental module, "
    "function and method signatures and "
    "behavior are subject to change or removal!"
)
