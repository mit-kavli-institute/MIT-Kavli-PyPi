def test_try_import():
    import pyticdb as _

    assert _ is not None
